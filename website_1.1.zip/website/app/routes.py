from flask import render_template
from app import app


@app.route('/')
@app.route('/index')
def index():
    user = {'username': 'john'},
    posts = [
        {
            'author': {'username': 'John Jacobs'},
            'body': 'I like apples!'
        },
        {
            'author': {'username': 'Susan Ormen'},
            'body': 'Good for you John!'
        },

    ]


    # user = {'username': 'michael'}
    return render_template('index.html', title='Home', user=user, posts=posts)
